// // index.js
// const express = require('express');
// const mysql = require('mysql');
// const cors = require('cors');

// // const app = express();
// // app.use(cors()); // CORS izinleri
// app.use(express.json()); // JSON verisini parse etmek için

// // MySQL bağlantı ayarları
// const connection = mysql.createConnection({
//   host: '10.33.22.208',
//   user: 'root',
//   password: 'Bel33.Mez33', // şifreniz varsa buraya yazın
//   database: 'talep' // 
// });

// // Bağlantıyı başlat
// connection.connect((err) => {
//   if (err) throw err;
//   console.log('MySQL bağlantısı başarılı.');
// });
